
# GPU-Powered Image Processing and Performance Analyzer

## Overview
This project demonstrates GPU acceleration using CUDA for batch image processing.

## Features
- Custom CUDA grayscale conversion kernel
- Custom CUDA Sobel edge detection kernel
- CPU vs GPU performance comparison
- Batch benchmarking for 10, 25, 50 and 100 images
- Execution time and speedup calculation
- CSV performance report
- Performance graphs
- Output image comparison

## Technology Stack
- Python
- NVIDIA CUDA
- CuPy
- NumPy
- OpenCV
- Pandas
- Matplotlib
- Google Colab

## Hardware
NVIDIA Tesla T4 GPU

## Results
The results folder contains:
- performance_results.csv
- cpu_vs_gpu.png
- gpu_speedup.png
- output_comparison.png
- execution_log.txt
- Processed output images

## Execution
Open GPU_Capstone_Image_Processing.ipynb in Google Colab.
Enable GPU runtime and execute cells sequentially.

## Note
Benchmark timings include data transfer and processing overhead.
Actual speedup depends on batch size and runtime conditions.
